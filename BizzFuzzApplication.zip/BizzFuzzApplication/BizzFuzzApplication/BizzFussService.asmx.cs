﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace BizzFuzzApplication
{
    /// <summary>
    /// Summary description for BizzFussService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class BizzFussService : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }
        [WebMethod]
        public void BizzFuzz()
        {
            //int num = 0;
            for (int i = 1; i < 101; i++)
            {
                if (i%5==0)
                {
                    Console.WriteLine("Buck");
                }
                if (i%3==0)
                {
                    Console.WriteLine("Fizz");
                }

                if (i%3==0 && i%5==0)
                {
                    Console.WriteLine("BuckFizz");
                }
                if (i % 3 != 0 && i % 5 != 0)
                {
                    Console.WriteLine(i);
                }
                

            }
        }
    }
}
