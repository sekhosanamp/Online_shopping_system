﻿using Online_Shopping_System.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace Online_Shopping_System.Controllers
{
    public class AccountsController : Controller
    {
        //
        // GET: /Accounts/

        public ActionResult Register_Customer()
        {
            ViewBag.Success = "";
            ViewBag.ErrorFound = "";

            return View();
        }

        [HttpPost]
        public ActionResult Register_Customer(Register_Customer model)
        {


            #region commented code
            //OnlineShopDBDataContext CustContext = new OnlineShopDBDataContext();
            //Customer regp = new Customer()

            //{



            //    surname = regCust.surname,
            //    passwd = regCust.password,
            //    email = regCust.email,
            //    contactNr = regCust.contactNr,
            //    cust_state = regCust.cust_state,
            //    city = regCust.city,
            //    pinCode = regCust.pinCode,
            //    Account_status = regCust.Account_status,
            //    fullnames = regCust.fullnames

            //};

            //CustContext.Customers.InsertOnSubmit(regp);
            //CustContext.SubmitChanges();

            #endregion

            ViewBag.Success = "";
            ViewBag.ErrorFound = "";
            string CatchError = "";

            Register_CustomerLogics Logics = new Register_CustomerLogics();

            if(Logics.InsertNewCustomer(model,ref CatchError))
            {
                ViewBag.Success = "Your Account is successfully created";
            }
            else
            {
                ViewBag.ErrorFound = CatchError;
            }
            
            return View();
        }

        public ActionResult Register_Admin()
        {

            ViewBag.Success = "";
            ViewBag.ErrorFound = "";

            return View();
        }
        [HttpPost]
        public ActionResult Register_Admin( RegisterAdmin model)
        {
            ViewBag.Success = "";
            ViewBag.ErrorFound = "";
            string CatchError = "";

            RegisterAdminLogics Logics = new RegisterAdminLogics();

            if (Logics.RegisterNewAdmin(model, ref CatchError))
            {
                ViewBag.Success = "Admin Succefully registered";
            }
            else
            {
                ViewBag.ErrorFound = CatchError;
            }

            return View();

           }
        public string CreatePassword(int length)
        {
            const string valid = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            StringBuilder res = new StringBuilder();
            Random rnd = new Random();
            while (0 < length--)
            {
                res.Append(valid[rnd.Next(valid.Length)]);
            }
            return res.ToString();
        }
        public ActionResult LostPassword()
        {
            return View();
        }
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult LostPassword(LostPassword model)
        {
            if (ModelState.IsValid)
            {
                MembershipUser user;
                using (var context = new OnlineShopDBDataContext ())
                {
                    var foundUserName = (from u in context.Customers
                                         where u.email == model.Email
                                         select u.fullnames).FirstOrDefault();
                    if (foundUserName != null)
                    {
                        user = Membership.GetUser(foundUserName.ToString());
                    }
                    else
                    {
                        user = null;
                    }
                }
                if (user != null)
                {
                    // Generae password token that will be used in the email link to authenticate user
                    var token = CreatePassword(6);
                    // Generate the html link sent via email
                    string resetLink = "<a href='"
                       + Url.Action("ResetPassword", "Account", new { rt = token }, "http")
                       + "'>Reset Password Link</a>";

                    // Email stuff
                    string subject = "Reset your password for asdf.com";
                    string body = "You link: " + resetLink;
                    string from = "donotreply@asdf.com";

                    MailMessage message = new MailMessage(from, model.Email);
                    message.Subject = subject;
                    message.Body = body;
                    SmtpClient client = new SmtpClient();

                    // Attempt to send the email
                    try
                    {
                        client.Send(message);
                    }
                    catch (Exception e)
                    {
                        ModelState.AddModelError("", "Issue sending email: " + e.Message);
                    }
                }
                else // Email not found
                {
                    /* Note: You may not want to provide the following information
                    * since it gives an intruder information as to whether a
                    * certain email address is registered with this website or not.
                    * If you're really concerned about privacy, you may want to
                    * forward to the same "Success" page regardless whether an
                    * user was found or not. This is only for illustration purposes.
                    */
                    ModelState.AddModelError("", "No user found by that email.");
                }
            }

            /* You may want to send the user to a "Success" page upon the successful
            * sending of the reset email link. Right now, if we are 100% successful
            * nothing happens on the page. :P
            */
            return View(model);
        }
        // GET: /Account/ResetPassword
                [AllowAnonymous]
            public ActionResult ResetPassword(string rt)
            {
                    NewPasswordChange model = new NewPasswordChange();
                 model.ReturnToken = rt;
                    return View(model);
            }
                // POST: /Account/ResetPassword
                [HttpPost]
                [AllowAnonymous]
                [ValidateAntiForgeryToken]
                public ActionResult ResetPassword(NewPasswordChange model)
                {
                    if (ModelState.IsValid)
                    {
                        string resetResponse = CreatePassword(6);
                        if (resetResponse !=null)
                        {
                            ViewBag.Message = "Successfully Changed";
                        }
                        else
                        {
                            ViewBag.Message = "Something went horribly wrong!";
                        }
                    }
                    return View(model);
                }
	}
}