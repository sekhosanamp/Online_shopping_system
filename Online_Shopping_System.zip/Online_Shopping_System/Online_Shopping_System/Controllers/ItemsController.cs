﻿using Online_Shopping_System.Models;
using Online_Shopping_System.Views.Items;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Services;

namespace Online_Shopping_System.Controllers
{
    public class ItemsController : Controller
    {
        List<SelectListItem> lstcate ;
 


       public static string strcatid = "Not Set";
        //
        // GET: /Items/
        public string striname = "";

         [HttpGet]
        public ActionResult AddItems()
        {


            ViewBag.dateadded = DateTime.Now.ToString();
            populatedroplist();
         

            return View();
        }

         //Onclick even for Add items


        [HttpPost]
        public ActionResult AddItems(Items model) 
        {
            ViewBag.dateadded = DateTime.Now.ToString();
            populatedroplist();

            ItemsLogics Logics = new ItemsLogics();
            if (Logics.AddNewItem(model))
            {
              Content("<script language='javascript' type='text/javascript'>alert('Item is successfully added');</script>");
            }



            return View();
        }




        public void populatedroplist()
        {
            OnlineShopDBDataContext dbcontext = new OnlineShopDBDataContext();
            Product pro = new Product();
            ArrayList arryProcucts = new ArrayList();
            ArrayList arryProIds = new ArrayList();


            arryProcucts.Clear();
            arryProIds.Clear();
            ////using viewdata  
            var vrpodnames = dbcontext.Products.ToList();
          

               List<SelectListItem> items = new List<SelectListItem>();
               int count = 0;
               items.Add(new SelectListItem
               {
                   Text = "Please Select",
                   Value = "-1"

               });
               arryProcucts.Add("Please Select");
               arryProIds.Add("-1"); 
               foreach (var itm in vrpodnames)
               {

                   items.Add(new SelectListItem
                   {
                       Text = itm.prodname,
                       Value = itm.prod.ToString()

                   });
                   arryProcucts.Add(itm.prodname);
                   arryProIds.Add(itm.prod.ToString()); 
                   count++;

               }

            ViewBag.drpprodnames = items;

            ViewBag.arryProdnames = arryProcucts;
            ViewBag.arryProdIds = arryProIds;
        


            //populatecate
            var vrcatnames = dbcontext.Categories.ToList();

             lstcate = new List<SelectListItem>();

            lstcate.Add(new SelectListItem
            {
                Text = "Please Select",
                Value = "-1"

            });
            foreach (var itm in vrcatnames)
            {

                lstcate.Add(new SelectListItem
                {
                    Text = itm.catname,
                    Value = itm.CatID.ToString()

                });

              

            }
            ViewBag.drpprodcategories = lstcate;
        }

    

        
   
        [HttpGet]
        public JsonResult getcategoryid(string id)
        {
            OnlineShopDBDataContext dbcontext = new OnlineShopDBDataContext();
      

            ////using viewdata  
            //populatecate
            var vrcatnames = dbcontext.Categories.ToList();
            List<SelectListItem> lstcate= new List<SelectListItem>();
          
            int count = 1;
            foreach (var itm in vrcatnames)
            {

                lstcate.Add(new SelectListItem
                {
                    Text = itm.CatID.ToString(),
                    Value = count.ToString()


                });

                count++;

            }

            string new_id="";
            foreach (var item in lstcate)
            {

                if (getProcuctRefID(id)== item.Text.ToString())
                {
                    new_id = item.Value;
                    break;
                }
             

            }

            return Json(new_id,JsonRequestBehavior.AllowGet);
        }

      
        private string getProcuctRefID(string prodid)
        {
          
            try
            {

            OnlineShopDBDataContext dbcontext = new OnlineShopDBDataContext();
          

            ////using viewdata  
            var vrpodnames = dbcontext.Products.Where(p => p.prod == Convert.ToInt32(prodid)).ToList();

             foreach (var itm in vrpodnames)
            {
                strcatid = itm.catID.ToString();
            }
            }
            catch (Exception)
            {
                
              
            }
             return strcatid;
        }



        [HttpGet]
        public JsonResult populateproducts(string id)
        {

            ArrayList strProcuts = new ArrayList();
            try
            {
              OnlineShopDBDataContext dbcontext = new OnlineShopDBDataContext();
          

       
            ////using viewdata  
            var vrpodnames = dbcontext.Products.Where(p => p.catID == Convert.ToInt32(id)).ToList();

            strProcuts.Clear();

            foreach (var item in vrpodnames)
            {
                strProcuts.Add (item.prodname);
            
            }


       
            }
            catch (Exception)
            {
                
              
            }

       
          

            return Json(strProcuts, JsonRequestBehavior.AllowGet);
        }



        //Adding Category



        [HttpGet]
        public ActionResult AddCategory()
        {
           
            ViewBag.DateAdded = DateTime.Now.ToString();
            ViewBag.ErrorFound = "";
            ViewBag.CategoryAdded = "";



            return View();
        }





        [HttpPost]
        public ActionResult AddCategory(AddCategory  model)
        {
            ViewBag.DateAdded = DateTime.Now.ToString();
            string StrCachError="" ;
           
            CategoryLogics logics = new CategoryLogics();

            if(logics.AddNewItem(model,ref StrCachError))
            {
                ViewBag.ErrorFound = StrCachError;
                ViewBag.CategoryAdded = "Category is successfully Saved";
            }
            else
            {
                ViewBag.ErrorFound = StrCachError; 
            }


           
            return View();
        }



        //Adding new Category

        

            
        [HttpGet]
        public ActionResult AddProduct()
        {

            ViewBag.DateAdded = DateTime.Now.ToString();
            ViewBag.ProductAdded = "";
            ViewBag.ErrorFound = "";
            ProductLogics product = new ProductLogics();
            PopulateForProduct();
           

      
            return View();
        }


        [HttpPost]
        public ActionResult AddProduct(AddProduct model)
        {
            ProductLogics Logics = new ProductLogics();
            ViewBag.DateAdded = DateTime.Now.ToString();
            ViewBag.ProductAdded = "";
            ViewBag.ErrorFound = "";
            PopulateForProduct();
            string StrCatchError = "";

            if(Logics.InsertNewProduct(model, ref StrCatchError))
             {
                 ViewBag.ProductAdded = "Product is Successfully Saved";
                 ViewBag.ErrorFound = StrCatchError;
             }
            else
            {
                ViewBag.ErrorFound = StrCatchError;
            }




            return View();
        }



        private void PopulateForProduct()
        {
            List<SelectListItem> Categories = new List<SelectListItem>();
            OnlineShopDBDataContext Context = new OnlineShopDBDataContext();
            var VarCategories = Context.Categories.ToList();

            foreach (var item in VarCategories)
            {
                Categories.Add(new SelectListItem
                {
                    Text = item.catname,
                    Value = item.CatID.ToString()
                });
            }

            ViewBag.DrbCategories = Categories;
        }
	}
}











