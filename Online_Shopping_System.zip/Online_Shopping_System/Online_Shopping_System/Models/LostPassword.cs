﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Online_Shopping_System.Models
{
    public class LostPassword
    {
       
      
            [Required(ErrorMessage = "We need your email to send you a reset link!")]
            [Display(Name = "Your account email")]
            [EmailAddress(ErrorMessage = "Not a valid email--what are you trying to do here?")]
            public string Email { get; set; }
       
    }
}