﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Online_Shopping_System.Models
{
    public class Items
    {
        public string itemid { get; set; }
        public string Category { get; set; }
        public string Product { get; set; }

        [Required(ErrorMessage = "*")]
        public string itemname { get; set; }
        [Required(ErrorMessage = "*")]
        public string itemdesc { get; set; }
        [Required(ErrorMessage = "*")]
        public string itemdateadded { get; set; }




















    }
}