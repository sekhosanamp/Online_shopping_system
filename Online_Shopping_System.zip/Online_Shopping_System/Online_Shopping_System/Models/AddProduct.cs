﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Online_Shopping_System.Models
{
    public class AddProduct
    {
       
         public string GetCategoryID { get; set; } 

         [Required(ErrorMessage = "*")]
        public string ProductName { get; set; }
         [Required(ErrorMessage = "*")]
        public string ProductDesc { get; set; }
         [Required(ErrorMessage = "*")]
        public string DateAdded { get; set; }

        



    }
}