﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Online_Shopping_System.Models
{
    public class ItemsLogics
    {

        public bool AddNewItem(Items item)
        {
            bool blnsuccess = false;

            // return RedirectToAction("MyIndex","dddddd");



  //To insert New Item 
                try
                {

                    OnlineShopDBDataContext context = new OnlineShopDBDataContext();
                    context.insertnewitem(GenerateItemKey(item), item.itemname, item.itemdesc, DateTime.Now.ToString(), Convert.ToInt32(GetProductId(item.Product)));
                    context.SubmitChanges();
                    blnsuccess = true;
                }
                catch (Exception)
                {


                }
            
           

            return blnsuccess;
        }



        public string GetProductId(string ProductName)
        {
            string ProductId = "";
            OnlineShopDBDataContext context = new OnlineShopDBDataContext();
            var Products = context.Products.Where(p => p.prodname == ProductName).ToList();

            foreach (var item in Products)
            {
                ProductId = item.prod.ToString();
            }



            return ProductId;
        }



        //get number of items
        private int GetNoofItems()
        {
            int count = 0;
            OnlineShopDBDataContext context = new OnlineShopDBDataContext();
            var Products = context.Items.ToList();

            foreach (var item in Products)
            {
                count++;
            }


            return count;
        }


        private string GenerateItemKey(Items item)
        {
            string ItemKey = "";

            ItemKey = item.Category + GetProductId(item.Product) + GetNoofItems();


            return ItemKey;
        }

        public string CheckForErrors(Items item)
        {
            string Error = "";

            if (Convert.ToInt32(item.Category) < 1)
            {
                Error = "Please select the category";
            }


            if (item.Product.ToLower() == "please select")
            {
                Error = "Please select the category";
            }



            return Error;
        }




    }
}