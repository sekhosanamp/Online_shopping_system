﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Online_Shopping_System.Models
{
    public class ManageCustomerLogics
    {
        public bool DeactivateCustomer(SuspendCustomer customer, string CustID)
        {
            bool Suspended = false;

            if (InsertDeactivate(customer, CustID))
            {
                if (UpdateCustomerStatus(Convert.ToInt32(CustID), "Deactivated"))
                {
                    Suspended = true;
                }

            }

            return Suspended;
        }


        //public bool SuspendCustomer(SuspendCustomer customer, string CustID)
        //{
        //    bool Suspended = false;

        //     if(InsertSusP(customer,CustID))
        //     {
        //         if(UpdateCustomerStatus(Convert.ToInt32(CustID) , "Suspended"))
        //         {
        //             Suspended = true;
        //         }
                    
        //     }

        //    return Suspended;
        //}
        public bool InsertDeactivate(SuspendCustomer customer, string CustID)
        {
            bool Success = false;

            #region Commented Code
            //suspended_customer NewData = new suspended_customer()
            //{
            //    cust_id = Convert.ToInt32(CustID),
            //    susp_reason = customer.ReasonForSupension,
            //    duration = customer.SupensionDuration,
            //    Dura_type = customer.dura_type,
            //    susp_date = DateTime.Now.ToString()
            //};
            //Context.suspended_customers.InsertOnSubmit(NewData);
            #endregion
            OnlineShopDBDataContext Context = new OnlineShopDBDataContext();

         //   Context.InsertSupsCust(customer.ReasonForSupension, customer.SupensionDuration, Convert.ToInt32(CustID), DateTime.Now.ToString(), customer.dura_type);

           // Context.InsertDeactivatedCust(customer.ReasonForSupension,Convert.ToInt32(CustID), DateTime.Now.ToString());
            Context.SubmitChanges();
            Success = true;


            return Success;
        }
        //public bool InsertSusP(ManageCustomer customer , string CustID)
        //{
        //    bool Success = false;

        //    #region Commented Code
        //    //suspended_customer NewData = new suspended_customer()
        //    //{
        //    //    cust_id = Convert.ToInt32(CustID),
        //    //    susp_reason = customer.ReasonForSupension,
        //    //    duration = customer.SupensionDuration,
        //    //    Dura_type = customer.dura_type,
        //    //    susp_date = DateTime.Now.ToString()
        //    //};
        //    //Context.suspended_customers.InsertOnSubmit(NewData);
        //    #endregion
        //    OnlineShopDBDataContext Context = new OnlineShopDBDataContext();
                
        //       // Context.InsertSupsCust(customer.ReasonForSupension, customer.SupensionDuration, Convert.ToInt32(CustID), DateTime.Now.ToString(), customer.dura_type);
           
        //        Context.SubmitChanges();
        //        Success = true;


        //    return Success;
        //}
        public bool UpdateCustomerStatus(int CustId,string New_Status)
        {
            bool Success = false;

            try
            {
                OnlineShopDBDataContext Context = new OnlineShopDBDataContext();
             //   Context.UpdateCustomerStatus(CustId,New_Status);
                Context.SubmitChanges();
                Success = true;

            }
            catch (Exception ex)
            {
                
              
            }


            return Success;
        }

        
    }
}