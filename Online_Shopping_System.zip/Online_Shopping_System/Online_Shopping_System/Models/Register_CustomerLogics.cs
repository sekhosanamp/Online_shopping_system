﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Online_Shopping_System.Models
{
    public class Register_CustomerLogics
    {


        public bool InsertNewCustomer(Register_Customer Customer,ref string ErrorFound)
        {
            bool Success = false;
            ErrorFound = "";

            if(Compare(Customer.email,Customer.ConfirmEmail))
            {
                if (CheckLength(Customer.password))
                {


                    if (Compare(Customer.password, Customer.ConfirmPassword))
                    {
                        if (CheckIfCustomerExist(Customer.email) == false)
                        {
                            try
                            {
                                OnlineShopDBDataContext Context = new OnlineShopDBDataContext();
                                Context.InsertNewCust(Customer.surname, Customer.fullnames, Customer.email, Customer.contactNr, Customer.cust_state, Customer.city, Customer.pinCode, "Active", Customer.password, Customer.Address);
                                Context.SubmitChanges();
                                Success = true;

                            }
                            catch (Exception ex)
                            {
                                ErrorFound = ex.Message;
                            }
                        }
                        else
                        {
                            ErrorFound = "Someone already registered with this email";
                        }

                    }
                    else
                    {
                        ErrorFound = "Passwords do not match";
                    }
                }
                else
                {
                    ErrorFound = "Passwords must contain atleast 4 characters";
                }
            }
            else
            {
                ErrorFound = "Emails do not match";
            }
          


            return Success;
        }
        public bool CheckIfCustomerExist(string CustEmail)
        {
            bool Found = false;
            OnlineShopDBDataContext Context = new OnlineShopDBDataContext();
            var CustData = Context.Customers.ToList();

          

            var cust = Context.Customers.Where(c => c.email == CustEmail).ToList();
            

            if(cust.Count>0)
            {
                Found = true;
            }




            return Found;
        }


        public bool Compare(string Str1,string Str2)
        {
            bool Match = false;

            if(Str1==Str2)
            {

                Match = true;
            }
            return Match;
        }

        public bool CheckLength(string Str1)
        {
            bool length = false;

            if (Str1.Length >=4)
            {

                length = true;
            }
            return length;
        }
    }
}