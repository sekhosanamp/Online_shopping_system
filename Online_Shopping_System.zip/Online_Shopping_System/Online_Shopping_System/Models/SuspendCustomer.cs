﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Online_Shopping_System.Models
{
    public class SuspendCustomer
    {
        public string custName { get; set; }
        [Required(ErrorMessage = "*")]
        public string body { get; set; }
                [Required(ErrorMessage = "*")]
        public string ReasonForSupension { get; set; }
        [Required(ErrorMessage="*")]
        public string SupensionDuration { get; set; }
        public string susp_date { get; set; }
        public string dura_type { get; set; }
    }
}