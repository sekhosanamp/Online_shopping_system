﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Online_Shopping_System.Models
{
    public class RegisterAdmin
    {
    
        [Required(ErrorMessage = "*")]
        public string AdminName { get; set; }
        [Required(ErrorMessage = "*")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "*")]
        public string Password { get; set; }
        [Required(ErrorMessage = "*")]
        public string Email { get; set; }
        [Required(ErrorMessage = "*")]
        public string ContactNr { get; set; }
        [Required(ErrorMessage = "*")]
        public string ConfirmPassword { get; set; }
        [Required(ErrorMessage = "*")]
        public string ConfirmEmail { get; set; }
    }
}