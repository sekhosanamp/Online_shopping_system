﻿using Online_Shopping_System.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.WebPages.Html;

namespace Online_Shopping_System.Views.Items
{
    public class ProductLogics
    {


        public bool InsertNewProduct(AddProduct product , ref string StrError )
        {
            bool Success = false;
             StrError = "";

            try
            {
                if(CheckIfProductExist(product)==false)
                {
                    OnlineShopDBDataContext Context = new OnlineShopDBDataContext();
                    Context.AddNewProduct(product.ProductName, product.ProductDesc, 0, DateTime.Now.ToString(), Convert.ToInt32(product.GetCategoryID));
                    Context.SubmitChanges();
                    Success = true;
                }
                else
                {
                    StrError = "Product Already Exist";
                }
            }
            catch (Exception ex)
            {
                StrError = ex.Message;
               
            }

            return Success;
        }
        public bool CheckIfProductExist(AddProduct product)
        {
            bool Found = false;
            OnlineShopDBDataContext Context = new OnlineShopDBDataContext();
            var Categories = Context.Products.Where(C => C.prodname == product.ProductName).ToList();

            if (Categories.Count > 0)
            {
                return true;

            }


            return Found;

        }

       
        public List<SelectListItem> PopulateCate(){

            List<SelectListItem> Categories = new List<SelectListItem>();
            OnlineShopDBDataContext Context = new OnlineShopDBDataContext();
            var VarCategories = Context.Categories.ToList();

            foreach (var item in VarCategories)
            {
                Categories.Add(new SelectListItem
                {
                    Text = item.catname,
                    Value = item.CatID.ToString()
                });
            }





            return Categories;
        }
    }
}