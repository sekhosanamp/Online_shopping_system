﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Online_Shopping_System.Models
{
    public class RegisterAdminLogics
    {


        public bool RegisterNewAdmin(RegisterAdmin admin, ref string ErrorFound)
        {
            bool Success = false;
            ErrorFound = "";


            if (Compare(admin.Password, admin.ConfirmPassword))
            {

                if (Compare(admin.ConfirmEmail, admin.Email))
                {
                    if (CheckIfAdministrator(admin.Email)==false)
                    {
                        try
                        {
                            OnlineShopDBDataContext Context = new OnlineShopDBDataContext();
                            Context.registerAdmin(admin.AdminName, admin.LastName, admin.Email, admin.Password, admin.ContactNr);
                            Context.SubmitChanges();
                            Success = true;

                        }
                        catch (Exception ex)
                        {
                            ErrorFound = ex.Message;
                        } 
                    }
                    else
                    {
                        ErrorFound = "Administrator with this email already exists";
                    }
                   
                }
                else
                {
                    ErrorFound = "Emails are not matching";
                }
            }
            else
            {
                ErrorFound = "Passwords not matching";
            }

            return Success;
        }

        public bool CheckIfAdministrator(string adminEmail)
        {
            bool Found = false;
            OnlineShopDBDataContext Context = new OnlineShopDBDataContext();

              var admin = Context.Administrators.Where(c => c.email == adminEmail).ToList();


            if (admin.Count > 0)
            {
                Found = true;
            }




            return Found;
        }
        public bool Compare(string Str1, string Str2)
        {
            bool Match = false;

            if (Str1 == Str2)
            {

                Match = true;
            }
            return Match;
        }


    }
}