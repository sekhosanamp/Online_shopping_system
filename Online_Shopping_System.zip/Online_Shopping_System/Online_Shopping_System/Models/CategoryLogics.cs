﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Online_Shopping_System.Models
{
    public class CategoryLogics
    {
        public bool AddNewItem(AddCategory category , ref string ErrorText)
        {
            bool blnsuccess = false;
            ErrorText = "";
            // return RedirectToAction("MyIndex","dddddd");



            //To insert New Item 
            try
            {
                if(CheckIfCategoryExist(category.CatName)==false)
                {
                    OnlineShopDBDataContext context = new OnlineShopDBDataContext();
                    context.InsertCategory(category.CatName, DateTime.Now.ToString(), category.CatDesc, category.CatSearchkeys);
                    context.SubmitChanges();
                    blnsuccess = true;
                }
                else
                {

                    blnsuccess = false;
                    ErrorText = "Category already exist";
                }
               
            }
            catch (Exception ex)
            {
                ErrorText = ex.Message;

            }



            return blnsuccess;
        }



        private bool CheckIfCategoryExist(string CatName)
        {
            bool Found = false;
            OnlineShopDBDataContext Context = new OnlineShopDBDataContext();
            var Categories = Context.Categories.Where(C => C.catname == CatName).ToList();

            if(Categories.Count>0)
            {
                return true;
            
            }

            return Found;
        }

    }
}