﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Online_Shopping_System.Models
{
    public class Register_Customer
    {
        [Required(ErrorMessage = "*")]
        public string surname { get; set; }
        [Required(ErrorMessage = "*")]
        public string password { get; set; }
        [Required(ErrorMessage = "*")]
        public string fullnames { get; set; }
        [Required(ErrorMessage = "*")]
        public string email { get; set; }
        [Required(ErrorMessage = "*")]
        public string contactNr { get; set; }
        [Required(ErrorMessage = "*")]
        public string cust_state { get; set; }
         [Required(ErrorMessage = "*")]
        public string city { get; set; }
         [Required(ErrorMessage = "*")]
        public int pinCode { get; set; }
         [Required(ErrorMessage = "*")]
        public string ConfirmEmail{ get; set; }
         [Required(ErrorMessage = "*")]
         public string Address { get; set; }
         [Required(ErrorMessage = "*")]
         public string ConfirmPassword { get; set; }
    }
}