﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Online_Shopping_System.Models
{
    public class AddCategory
    {
        [Required(ErrorMessage = "*")]
        public string CatId { get; set; }
        [Required(ErrorMessage = "*")]
        public string CatName { get; set; }
        [Required(ErrorMessage = "*")]
        public string CatDesc { get; set; }
        [Required(ErrorMessage = "*")]
        public string CatDate { get; set; }
        public string CatSearchkeys { get; set; }
        public string CatFoundError { get; set; }  
        
    }
}